# BR-V5-POSTFIX-MAINT-SRCREFREEZE01-REPRO01 Report

## Verdict

`BR-V5-POSTFIX-MAINT-SRCREFREEZE01-REPRO01 = PASS / SELF_CONTAINED_POSTFIX_ARCHIVE_ONLY_BITWISE_REPRODUCTION_VALIDATED`

Planner acceptance is required. Release authorization is not self-granted.

## Archive-only input universe

- A `6bfa863ab45f77a97832ceb25c9dab916c29b5c4e5a39c816570fa713af4658b`
- B-postfix `1445e2bb41d25063102b53e041bec8b8210b4b6ad1729eb1d394b2a656b43c73`
- C-postfix `7f9463b8b5133775080f44044ad68d692ffb398e62de375ea4c7fa25fb42389a`
- lineage `4e154c4ea64cb2b306d90b8ccd2475e2abbdca51229e1f72917aa1cf6492ab68`

Only exact Project data-source A/B/C artifacts were resolved, authenticated and then
isolated into an allowlisted fresh generation mirror. Project history, File Library
substitutes, nested postfix evidence target payloads, installed game files and network
bytes were not generation inputs.

## Non-runtime reproduction

- direct plaintext script authority `ba565c667981168fa8b987fb5d40689461a3d7a87c635e6539a413870325b417` — PASS
- canonical font machinery / no-op controls / DDS / regenerated system.json — PASS
- PBRT candidate `edbd65e66eb9e650be0cbe8a3763cd669eb7f1a15b0e7005148d993431a26219` / 10418010 bytes — PASS
- PBRT clean double build byte-identical — PASS

## Runtime continuation

The same-lineage archive-only handoff was applied with archived EasyPatcher on Windows.
Returned exact targets:

- script.mpk `d12dfb0b833058dfe952af65ab9c7d8c70ecb5f1d8d82e128da8b564d0b7c1dc` / 4639574 bytes
- system.mpk `83ec04c94f16f65d3f056a1297c580a4ddb6f6522311e9b74d51f490ef24e109` / 169604760 bytes

The returned script.mpk was independently re-parsed after return against the C-postfix
86-row SCX ledger. All 86 MPK/SCX positions match; 78 patched streams also satisfy the
accepted transform/mapping model, including `_TIPS.SCX` 0..923 and `_SYSTEM.SCX`
sparse bridge 79..88 -> 139..148.

## Coverage

`96/96 PASS`

- 86 exact SCX/MPK ledger positions
- 10 C-postfix mandatory top-level targets
- NOT_RUN = 0

## Status

`CURRENT_RELEASE_STATUS = NOT_YET_RELEASE_AUTHORIZED`

Successor after Planner acceptance: final change-impact release gate.
