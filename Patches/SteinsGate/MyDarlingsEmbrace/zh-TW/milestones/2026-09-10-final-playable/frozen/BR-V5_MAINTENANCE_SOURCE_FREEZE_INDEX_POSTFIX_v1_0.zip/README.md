# BR-V5 Maintenance Source Freeze Index -- Postfix

Use exact inherited Artifact A together with B-postfix and this C-postfix for the successor independent archive-only reproduction.
